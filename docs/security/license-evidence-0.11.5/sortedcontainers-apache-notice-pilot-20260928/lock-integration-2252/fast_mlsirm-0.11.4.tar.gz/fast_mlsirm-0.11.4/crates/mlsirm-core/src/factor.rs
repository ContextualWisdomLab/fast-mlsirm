//! Minimum-residual (minres/ULS) exploratory factor analysis and
//! McDonald's omega_total for the unidimensional (1-factor) case.
//!
//! # Sources actually read
//!
//! - READ: Revelle's CRAN psych `R/fa.R` (fetched from
//!   raw.githubusercontent.com/cran/psych/master/R/fa.R, 2026-07-23), the
//!   minres path: `fit.residuals`, `fit`, `FAgr.minres`, `FAout.wls`, and
//!   the smc-based start values. Transcribed line by line.
//! - READ (prior work in this crate): psych `smc.R` conventions, already
//!   mirrored by `reliability::invert_symmetric` + clamping for lambda6.
//! - NOT READ: McDonald (1999). The omega_total formula below is
//!   hand-derived from the unidimensional standardized factor model
//!   (derivation in the docs of [`omega_total_1f_corr`]) and matches what
//!   secondary sources attribute to McDonald; we cite it as
//!   "as cited in Revelle, 2025".
//!
//! # Algorithm (psych fa.R, minres path)
//!
//! Optimization variable: uniquenesses `psi in [0.005, 1]^p` (correlation
//! metric). Start: `1 - smc_j`. Objective: replace `diag(S)` by `1 - psi`,
//! eigendecompose, clamp eigenvalues `< eps` to `100*eps`, form the
//! rank-`nf` model `Lambda Lambda'` from the top eigenpairs, and sum the
//! squared strictly-lower-triangle residuals of `S - model`
//! (`fit.residuals`, `fm = "minres"`).
//!
//! Search direction: psych's `FAgr.minres`,
//! `g = diag(Lambda Lambda' + diag(psi) - S)` with eigenvalue clamp
//! `max(., 0)`. VERIFIED LIMITATION (adversarial spec review): this is NOT
//! the exact analytic gradient of the lower-triangle objective —
//! finite-difference signs can disagree. It is therefore used only as a
//! cheap search direction inside a projected Barzilai-Borwein descent with
//! an Armijo safeguard and a central finite-difference fallback direction.
//! Convergence is asserted on the ACTUAL objective via a finite-difference
//! box-KKT check (interior: `|fd_j| <= tol`; at the lower bound:
//! `fd_j >= -tol`; at the upper bound: `fd_j <= tol`); the maximum
//! violation is returned as [`MinresFaResult::kkt_violation`] so tests can
//! read it.
//!
//! Final loadings (`FAout.wls`): eigendecompose `S - diag(psi_hat)`,
//! `Lambda = V_{1:nf} diag(sqrt(max(lambda_k, 0)))`, columns in descending
//! eigenvalue order. Sign convention (ours, documented): each column is
//! flipped so its sum is `>= 0`. Loadings are orthogonal (unrotated); no
//! rotation of any kind is implemented.
//!
//! # Divergences from psych (documented)
//!
//! - Optimizer: psych uses `optim(..., method = "L-BFGS-B")`; we use
//!   projected BB descent + Armijo as above. Tests assert agreement with an
//!   independent scipy L-BFGS-B transcription oracle (same algorithm family
//!   as R's optim; NOT claimed bit-identical to any R run) at 1e-5.
//! - Upper bound: psych's `upper = max(smc, 1)` can exceed 1 for a
//!   covariance input; only correlation input is supported here, so the
//!   box is `[0.005, 1]`.
//! - No rotation, no factor scores, no ML/WLS/GLS/minchi methods, no
//!   omega_hierarchical (would need oblimin + Schmid-Leiman; out of scope
//!   per the REDUCED-SCOPE spec decision).
//!
//! # References (APA 7th ed.)
//!
//! Revelle, W. (2025). *psych: Procedures for psychological, psychometric,
//! and personality research* (Version 2.6.5) [R package].
//! https://CRAN.R-project.org/package=psych
//!
//! McDonald, R. P. (1999). *Test theory: A unified treatment*. Erlbaum.
//! (As cited in Revelle, 2025; not read.)

use crate::parallel::correlation_matrix;
use crate::reliability::invert_symmetric;

const LOWER: f64 = 0.005;
const UPPER: f64 = 1.0;
const KKT_TOL: f64 = 1e-6;
const MAX_ITER: usize = 2000;
const JACOBI_MAX_SWEEPS: usize = 128;
const JACOBI_TOL: f64 = 1e-12;

/// Minres factor-analysis output. `loadings` is `p x nf` row-major,
/// unrotated, columns in descending-eigenvalue order, column sums >= 0.
#[derive(Debug, Clone)]
pub struct MinresFaResult {
    pub loadings: Vec<f64>,
    /// Estimated uniquenesses `psi_hat` (box-constrained to [0.005, 1]).
    pub uniquenesses: Vec<f64>,
    /// Communalities `h2_j = sum_k loading_{jk}^2`.
    pub communalities: Vec<f64>,
    /// Final value of the minres objective (sum of squared strictly
    /// lower-triangle residuals).
    pub objective: f64,
    /// Maximum finite-difference box-KKT violation of the actual objective
    /// at the solution (see module docs). Small (< ~1e-6) iff converged.
    pub kkt_violation: f64,
    pub n_iter: usize,
    pub converged: bool,
}

/// McDonald's omega_total for a 1-factor minres solution.
#[derive(Debug, Clone)]
pub struct OmegaResult {
    /// `(sum lambda)^2 / ((sum lambda)^2 + sum psi)`.
    pub omega_total: f64,
    pub fa: MinresFaResult,
}

/// Symmetric Jacobi eigendecomposition returning descending eigenvalues
/// with matching eigenvectors (columns of `v`, row-major `p x p`). Same
/// sweep scheme as `parallel::symmetric_eigenvalues_desc`, extended with
/// vector accumulation.
pub(crate) fn symmetric_eigen_desc(
    matrix: &[f64],
    p: usize,
) -> Result<(Vec<f64>, Vec<f64>), String> {
    let mut a = matrix.to_vec();
    let mut v = vec![0.0; p * p];
    for i in 0..p {
        v[i * p + i] = 1.0;
    }
    for _ in 0..JACOBI_MAX_SWEEPS {
        let mut off = 0.0_f64;
        for i in 0..p {
            for j in (i + 1)..p {
                off = off.max(a[i * p + j].abs());
            }
        }
        if off < JACOBI_TOL {
            let mut idx: Vec<usize> = (0..p).collect();
            idx.sort_by(|&x, &y| {
                a[y * p + y]
                    .partial_cmp(&a[x * p + x])
                    .expect("eigenvalues are finite")
            });
            let ev: Vec<f64> = idx.iter().map(|&i| a[i * p + i]).collect();
            let mut vs = vec![0.0; p * p];
            for (col, &i) in idx.iter().enumerate() {
                for r in 0..p {
                    vs[r * p + col] = v[r * p + i];
                }
            }
            return Ok((ev, vs));
        }
        for i in 0..p {
            for j in (i + 1)..p {
                let aij = a[i * p + j];
                if aij.abs() < JACOBI_TOL {
                    continue;
                }
                let theta = (a[j * p + j] - a[i * p + i]) / (2.0 * aij);
                let sign = if theta >= 0.0 { 1.0 } else { -1.0 };
                let t = sign / (theta.abs() + (theta * theta + 1.0).sqrt());
                let c = 1.0 / (t * t + 1.0).sqrt();
                let s = t * c;
                for k in 0..p {
                    let aik = a[i * p + k];
                    let ajk = a[j * p + k];
                    a[i * p + k] = c * aik - s * ajk;
                    a[j * p + k] = s * aik + c * ajk;
                }
                for k in 0..p {
                    let aki = a[k * p + i];
                    let akj = a[k * p + j];
                    a[k * p + i] = c * aki - s * akj;
                    a[k * p + j] = s * aki + c * akj;
                }
                for k in 0..p {
                    let vki = v[k * p + i];
                    let vkj = v[k * p + j];
                    v[k * p + i] = c * vki - s * vkj;
                    v[k * p + j] = s * vki + c * vkj;
                }
            }
        }
    }
    Err("Jacobi eigenvalue iteration did not converge".into())
}

/// Top-`nf` loadings from `S` with diagonal replaced by `1 - psi`
/// (psych `fit.residuals` eigen step; eigenvalue floor `100 * eps`).
fn loadings_at(
    s: &[f64],
    psi: &[f64],
    p: usize,
    nf: usize,
    floor_eps: bool,
) -> Result<Vec<f64>, String> {
    let mut sstar = s.to_vec();
    for j in 0..p {
        sstar[j * p + j] = 1.0 - psi[j];
    }
    let (ev, vecs) = symmetric_eigen_desc(&sstar, p)?;
    let mut lambda = vec![0.0; p * nf];
    for k in 0..nf {
        let e = if floor_eps {
            if ev[k] < f64::EPSILON {
                100.0 * f64::EPSILON
            } else {
                ev[k]
            }
        } else {
            ev[k].max(0.0)
        };
        let root = e.sqrt();
        for r in 0..p {
            lambda[r * nf + k] = vecs[r * p + k] * root;
        }
    }
    Ok(lambda)
}

/// psych `fit.residuals` (fm = "minres"): sum of squared strictly
/// lower-triangle residuals of `S - Lambda Lambda'`.
fn objective(s: &[f64], psi: &[f64], p: usize, nf: usize) -> Result<f64, String> {
    let l = loadings_at(s, psi, p, nf, true)?;
    let mut f = 0.0;
    for i in 1..p {
        for j in 0..i {
            let mut m = 0.0;
            for k in 0..nf {
                m += l[i * nf + k] * l[j * nf + k];
            }
            let r = s[i * p + j] - m;
            f += r * r;
        }
    }
    Ok(f)
}

/// psych `FAgr.minres` search direction (NOT the exact gradient of
/// `objective`; see module docs).
fn psych_direction(s: &[f64], psi: &[f64], p: usize, nf: usize) -> Result<Vec<f64>, String> {
    let l = loadings_at(s, psi, p, nf, false)?;
    let mut g = vec![0.0; p];
    for j in 0..p {
        let mut m = 0.0;
        for k in 0..nf {
            m += l[j * nf + k] * l[j * nf + k];
        }
        g[j] = m + psi[j] - s[j * p + j];
    }
    Ok(g)
}

/// Finite-difference gradient of the actual objective.
///
/// Uses central differences in the interior of `[LOWER, UPPER]^p`.  When
/// `psi[j]` is within `h` of a bound, falls back to a one-sided difference
/// that stays inside the feasible box, avoiding infeasible objective
/// evaluations that would bias the gradient estimate (and therefore
/// `kkt_violation`) at the boundary.
fn fd_gradient(s: &[f64], psi: &[f64], p: usize, nf: usize) -> Result<Vec<f64>, String> {
    let mut g = vec![0.0; p];
    let mut w = psi.to_vec();
    for j in 0..p {
        let h = 1e-7 * psi[j].abs().max(1.0);
        let orig = w[j];
        if orig - h < LOWER {
            // Forward difference: orig + h stays feasible.
            let f0 = objective(s, &w, p, nf)?;
            w[j] = orig + h;
            let fp = objective(s, &w, p, nf)?;
            w[j] = orig;
            g[j] = (fp - f0) / h;
        } else if orig + h > UPPER {
            // Backward difference: orig - h stays feasible.
            let f0 = objective(s, &w, p, nf)?;
            w[j] = orig - h;
            let fm = objective(s, &w, p, nf)?;
            w[j] = orig;
            g[j] = (f0 - fm) / h;
        } else {
            // Central difference (interior).
            w[j] = orig + h;
            let fp = objective(s, &w, p, nf)?;
            w[j] = orig - h;
            let fm = objective(s, &w, p, nf)?;
            w[j] = orig;
            g[j] = (fp - fm) / (2.0 * h);
        }
    }
    Ok(g)
}

/// Max finite-difference box-KKT violation at `psi` (see module docs).
fn kkt_violation(s: &[f64], psi: &[f64], p: usize, nf: usize) -> Result<f64, String> {
    let g = fd_gradient(s, psi, p, nf)?;
    let mut worst = 0.0_f64;
    for j in 0..p {
        let at_lower = psi[j] <= LOWER + 1e-10;
        let at_upper = psi[j] >= UPPER - 1e-10;
        let v = if at_lower {
            (-g[j]).max(0.0)
        } else if at_upper {
            g[j].max(0.0)
        } else {
            g[j].abs()
        };
        worst = worst.max(v);
    }
    Ok(worst)
}

fn clamp_box(v: f64) -> f64 {
    v.clamp(LOWER, UPPER)
}

fn validate_corr(s: &[f64], p: usize, what: &str) -> Result<(), String> {
    if p < 3 {
        return Err(format!("{what}: need at least 3 variables"));
    }
    let pp = p
        .checked_mul(p)
        .ok_or_else(|| format!("{what}: dimension overflow (p = {p})"))?;
    if s.len() != pp {
        return Err(format!(
            "{what}: expected a {p} x {p} correlation matrix, got length {}",
            s.len()
        ));
    }
    if s.iter().any(|v| !v.is_finite()) {
        return Err(format!("{what}: correlation matrix must be finite"));
    }
    for i in 0..p {
        if (s[i * p + i] - 1.0).abs() > 1e-8 {
            return Err(format!(
                "{what}: diagonal must be 1 (correlation metric); got {} at {i}",
                s[i * p + i]
            ));
        }
        for j in 0..i {
            if (s[i * p + j] - s[j * p + i]).abs() > 1e-8 {
                return Err(format!("{what}: matrix must be symmetric"));
            }
            // Impossible correlations overflow downstream eigen/minres
            // arithmetic (impl-review finding); reject at the boundary.
            if s[i * p + j].abs() > 1.0 + 1e-8 {
                return Err(format!(
                    "{what}: off-diagonal {} at ({i}, {j}) outside [-1, 1]",
                    s[i * p + j]
                ));
            }
        }
    }
    Ok(())
}

/// Minres factor analysis of a correlation matrix (psych fa.R, fm =
/// "minres"; see module docs for the transcription and divergences).
/// `corr` is row-major `p x p`; `1 <= nf < p`.
pub fn minres_fa_corr(corr: &[f64], p: usize, nf: usize) -> Result<MinresFaResult, String> {
    validate_corr(corr, p, "minres_fa")?;
    if nf == 0 || nf >= p {
        return Err("minres_fa: need 1 <= n_factors < n_variables".to_string());
    }

    // Start psi = 1 - smc (psych: diag(S) - smc(S)); errors on a singular
    // correlation matrix, matching the guttman_lambdas precedent.
    let rinv = invert_symmetric(corr, p)
        .map_err(|e| format!("minres_fa: smc start values need an invertible matrix: {e}"))?;
    let mut psi: Vec<f64> = (0..p)
        .map(|j| {
            let smc = (1.0 - 1.0 / rinv[j * p + j]).clamp(0.0, 1.0);
            clamp_box(1.0 - smc)
        })
        .collect();

    let mut f = objective(corr, &psi, p, nf)?;
    let mut g = psych_direction(corr, &psi, p, nf)?;
    let mut prev_psi = psi.clone();
    let mut prev_g = g.clone();
    let mut step = 1.0_f64;
    let mut n_iter = 0;
    for iter in 0..MAX_ITER {
        n_iter = iter + 1;
        // Armijo backtracking along the projected psych direction; central
        // FD direction as fallback when the psych direction fails (it is
        // not the exact gradient — see module docs).
        let mut accepted = false;
        for pass in 0..2 {
            let dir = if pass == 0 {
                g.clone()
            } else {
                fd_gradient(corr, &psi, p, nf)?
            };
            let mut t = step;
            for _ in 0..60 {
                let trial: Vec<f64> = (0..p).map(|j| clamp_box(psi[j] - t * dir[j])).collect();
                let moved: f64 = (0..p).map(|j| (trial[j] - psi[j]).abs()).sum();
                if moved <= 1e-15 {
                    break;
                }
                let ft = objective(corr, &trial, p, nf)?;
                let decrease: f64 = (0..p).map(|j| dir[j] * (psi[j] - trial[j])).sum();
                if ft <= f - 1e-4 * decrease.max(0.0) && ft < f {
                    prev_psi.copy_from_slice(&psi);
                    prev_g.copy_from_slice(&g);
                    psi = trial;
                    f = ft;
                    accepted = true;
                    break;
                }
                t *= 0.5;
            }
            if accepted {
                break;
            }
        }
        if !accepted {
            break;
        }
        g = psych_direction(corr, &psi, p, nf)?;
        // Barzilai-Borwein step for the next iteration.
        let mut ss = 0.0;
        let mut sy = 0.0;
        for j in 0..p {
            let sj = psi[j] - prev_psi[j];
            ss += sj * sj;
            sy += sj * (g[j] - prev_g[j]);
        }
        step = if sy.abs() > 1e-300 {
            (ss / sy).abs().clamp(1e-8, 1e4)
        } else {
            1.0
        };
        let moved: f64 = (0..p).map(|j| (psi[j] - prev_psi[j]).abs()).sum();
        if moved < 1e-13 {
            break;
        }
    }

    let kkt = kkt_violation(corr, &psi, p, nf)?;
    let loadings_raw = loadings_at(corr, &psi, p, nf, false)?;
    // Sign convention: column sums >= 0.
    let mut loadings = loadings_raw;
    for k in 0..nf {
        let colsum: f64 = (0..p).map(|r| loadings[r * nf + k]).sum();
        if colsum < 0.0 {
            for r in 0..p {
                loadings[r * nf + k] = -loadings[r * nf + k];
            }
        }
    }
    let communalities: Vec<f64> = (0..p)
        .map(|r| (0..nf).map(|k| loadings[r * nf + k].powi(2)).sum())
        .collect();
    Ok(MinresFaResult {
        loadings,
        uniquenesses: psi,
        communalities,
        objective: f,
        kkt_violation: kkt,
        n_iter,
        converged: kkt < KKT_TOL,
    })
}

/// Minres factor analysis of raw data (`n x p` row-major); computes the
/// Pearson correlation matrix first (same helper as parallel analysis).
pub fn minres_fa_data(
    data: &[f64],
    n: usize,
    p: usize,
    nf: usize,
) -> Result<MinresFaResult, String> {
    let np = n
        .checked_mul(p)
        .ok_or_else(|| format!("minres_fa: dimension overflow (n = {n}, p = {p})"))?;
    if data.len() != np {
        return Err(format!(
            "minres_fa: data length {} does not match n * p = {np}",
            data.len(),
        ));
    }
    if data.iter().any(|v| !v.is_finite()) {
        return Err("minres_fa: data must be finite (complete data required)".into());
    }
    if n < 3 {
        return Err("minres_fa: need at least 3 observations".into());
    }
    let r = correlation_matrix(data, n, p)?;
    minres_fa_corr(&r, p, nf)
}

/// McDonald's omega_total for the unidimensional case, from a 1-factor
/// minres fit of a correlation matrix.
///
/// Hand-derivation (self-contained; McDonald, 1999, as cited in Revelle,
/// 2025 — original not read): standardized 1-factor model
/// `X_j = lambda_j F + e_j` with `Var(F) = 1`, independent errors
/// `Var(e_j) = psi_j`. The common-score part of the unit-weight total is
/// `(sum_j lambda_j) F` with variance `(sum lambda)^2`; the error variance
/// is `sum psi`. Hence
///
/// ```text
/// omega_total = (sum lambda)^2 / ((sum lambda)^2 + sum psi)
/// ```
pub fn omega_total_1f_corr(corr: &[f64], p: usize) -> Result<OmegaResult, String> {
    let fa = minres_fa_corr(corr, p, 1)?;
    let lsum: f64 = fa.loadings.iter().sum();
    let psum: f64 = fa.uniquenesses.iter().sum();
    let den = lsum * lsum + psum;
    let omega_total = if den <= 1e-12 {
        f64::NAN
    } else {
        lsum * lsum / den
    };
    Ok(OmegaResult { omega_total, fa })
}

/// [`omega_total_1f_corr`] from raw data (`n x p` row-major).
pub fn omega_total_1f_data(data: &[f64], n: usize, p: usize) -> Result<OmegaResult, String> {
    let np = n
        .checked_mul(p)
        .ok_or_else(|| format!("omega_total_1f: dimension overflow (n = {n}, p = {p})"))?;
    if data.len() != np {
        return Err(format!(
            "omega_total_1f: data length {} does not match n * p = {np}",
            data.len(),
        ));
    }
    if data.iter().any(|v| !v.is_finite()) {
        return Err("omega_total_1f: data must be finite".into());
    }
    if n < 3 {
        return Err("omega_total_1f: need at least 3 observations".into());
    }
    let r = correlation_matrix(data, n, p)?;
    omega_total_1f_corr(&r, p)
}

/// Factor-analytic greatest lower bound to reliability (psych `glb.fa`).
#[derive(Debug, Clone, PartialEq)]
pub struct GlbFaResult {
    /// `sum(rr) / sum(R)` where `rr` is `R` with its diagonal replaced by
    /// the `nf`-factor minres communalities.
    pub glb: f64,
    /// Communalities from the `nf`-factor fit.
    pub communalities: Vec<f64>,
    /// Number of factors actually fitted (after the df adjustment).
    pub nf: usize,
}

/// Factor-analytic greatest lower bound to reliability, transcribed from
/// CRAN psych `glbs.R` `glb.fa` (read in full; Revelle, 2025):
///
/// 1. 1-factor minres fit; `values` = eigenvalues of `R` with the diagonal
///    replaced by the 1-factor model communalities (psych `fa()$values`
///    for `fm = "minres"`, traced in fa.R).
/// 2. `nf` = number of `values > 0` (strict).
/// 3. `df = p(p-1)/2 - nf*p + nf(nf-1)/2`; if `df < 0`, `nf -= 1` (single
///    decrement, exactly as psych — not a loop).
/// 4. Refit minres with `nf` factors; `glb = sum(rr)/sum(R)` with
///    `diag(rr)` = the `nf`-factor communalities.
///
/// This is NOT the true (algebraic) greatest lower bound: psych's
/// `glb.algebraic` solves a semidefinite program via Rcsdp (read; out of
/// scope here). Sijtsma (2009) and ten Berge & Socan (2004) discuss the
/// glb but were not read; the implementation claim is the psych `glb.fa`
/// transcription alone.
///
/// Divergences from psych (documented): input must already be a
/// correlation matrix (psych accepts rectangular data via
/// `cor(use = "pairwise")` and square covariance via `cov2cor`; use
/// [`glb_fa_data`] for the complete-data Pearson path); no `key`
/// reverse-scoring (caller responsibility); hard errors instead of R
/// error/warning strings; if the adjusted `nf` reaches 0 or `p` this
/// returns an error (psych's behavior there is unconfirmed from the read
/// source).
///
/// References (APA 7th ed.):
/// Revelle, W. (2025). psych: Procedures for psychological, psychometric,
///   and personality research (Version 2.6.5) [R package].
///   https://CRAN.R-project.org/package=psych
pub fn glb_fa_corr(corr: &[f64], p: usize) -> Result<GlbFaResult, String> {
    let f1 = minres_fa_corr(corr, p, 1)?;
    // S = R with diag replaced by 1-factor communalities.
    let mut s = corr.to_vec();
    for j in 0..p {
        s[j * p + j] = f1.communalities[j];
    }
    let (values, _) = symmetric_eigen_desc(&s, p)?;
    let mut nf = values.iter().filter(|&&v| v > 0.0).count();
    if nf >= 1 {
        let df = (p * (p - 1) / 2) as i64 - (nf * p) as i64 + (nf * (nf - 1) / 2) as i64;
        if df < 0 {
            nf -= 1;
        }
    }
    if nf < 1 || nf >= p {
        return Err(format!(
            "glb_fa: adjusted factor count {nf} outside 1..{p} (unsupported input)"
        ));
    }
    let fnf = minres_fa_corr(corr, p, nf)?;
    let mut sum_rr = 0.0;
    let mut sum_r = 0.0;
    for i in 0..p {
        for j in 0..p {
            let v = corr[i * p + j];
            sum_r += v;
            sum_rr += if i == j { fnf.communalities[i] } else { v };
        }
    }
    if sum_r.abs() <= 1e-8 {
        return Err(format!(
            "glb_fa: sum(R) too close to zero ({sum_r}); reliability ratio undefined"
        ));
    }
    Ok(GlbFaResult {
        glb: sum_rr / sum_r,
        communalities: fnf.communalities,
        nf,
    })
}

/// [`glb_fa_corr`] from raw data (`n x p` row-major, complete and finite);
/// computes the Pearson correlation matrix first.
pub fn glb_fa_data(data: &[f64], n: usize, p: usize) -> Result<GlbFaResult, String> {
    let np = n
        .checked_mul(p)
        .ok_or_else(|| format!("glb_fa: dimension overflow (n = {n}, p = {p})"))?;
    if data.len() != np {
        return Err(format!(
            "glb_fa: data length {} does not match n * p = {np}",
            data.len(),
        ));
    }
    if data.iter().any(|v| !v.is_finite()) {
        return Err("glb_fa: data must be finite (complete data required)".into());
    }
    if n < 3 {
        return Err("glb_fa: need at least 3 observations".into());
    }
    let r = correlation_matrix(data, n, p)?;
    glb_fa_corr(&r, p)
}

/// Velicer's minimum average partial (MAP) test output.
///
/// `f2[m]` / `f4[m]` for `m = 0..=max_m`: the average squared (resp.
/// elementwise fourth-power) off-diagonal partial correlation after
/// partialing out the first `m` principal components. Rows where the
/// partial covariance has a non-positive or non-finite diagonal entry are
/// invalid and stored as `NaN`; they are excluded from the argmin.
#[derive(Debug, Clone, PartialEq)]
pub struct VelicerMapResult {
    pub f2: Vec<f64>,
    pub f4: Vec<f64>,
    /// Number of components retained by the original (squared) criterion:
    /// the `m` (0-based, `m = 0` = baseline `R` itself) minimizing `f2`.
    pub retained_f2: usize,
    /// Retained count by the revised fourth-power criterion.
    pub retained_f4: usize,
}

/// Velicer's minimum average partial (MAP) test on a correlation matrix.
///
/// Algorithm (O'Connor's canonical MATLAB/SPSS MAP programs, READ;
/// cross-checked against psych `VSS.R` `map()`, READ):
///
/// 1. Eigendecompose `R`; PCA loadings `A = V diag(sqrt(lambda))` with
///    columns in descending-eigenvalue order.
/// 2. Baseline `m = 0`: `f2[0] = (sum(R.^2) - p) / (p(p-1))`, i.e. the
///    mean squared off-diagonal of `R` itself; `f4[0]` likewise with
///    fourth powers.
/// 3. For `m = 1..=max_m`: partial covariance `C* = R - A_m A_m'`
///    (`A_m` = first `m` columns), rescale
///    `R* = D^{-1/2} C* D^{-1/2}` with `D = diag(C*)`, then
///    `f2[m] = (sum(R*.^2) - p) / (p(p-1))` and `f4[m]` with fourth
///    powers. If any `diag(C*)` entry is `<= 1e-12` or non-finite the row
///    is invalid (`NaN`) — e.g. `R = I` after one component.
/// 4. Retained components = the `m` attaining the minimum over valid rows
///    (O'Connor: `nfacts = s - 1` with row 1 being `m = 0`).
///
/// Compatibility note (adversarial spec review): `fungible::faMAP` returns
/// `which.min(fm)`, a 1-based row POSITION whose first row is the `m = 0`
/// baseline — off by one relative to O'Connor's canonical count; that
/// convention is a bug and is NOT reproduced here. psych's internal
/// `map()` omits the `m = 0` baseline entirely and returns raw values
/// only.
///
/// Fourth-power caveat: the elementwise fourth power follows O'Connor's
/// code and `fungible::faMAP` (both READ). `EFA.dimensions::MAP` has since
/// switched to matrix powers claiming the elementwise form was wrong; the
/// Velicer, Eaton & Fava (2000) chapter was NOT read, so this conflict is
/// unresolved from primary literature — we follow O'Connor's de facto
/// standard code path.
///
/// `max_m` must satisfy `max_m <= p - 1` (canonical upper bound);
/// `max_m = 0` computes the baseline only.
///
/// References (APA 7th ed.):
///
/// Velicer, W. F. (1976). Determining the number of components from the
///   matrix of partial correlations. *Psychometrika, 41*(3), 321-327.
///   https://doi.org/10.1007/BF02293557 (Not read; formula support is the
///   read implementations below.)
/// O'Connor, B. P. (2000). SPSS and SAS programs for determining the
///   number of components using parallel analysis and Velicer's MAP test.
///   *Behavior Research Methods, Instruments, & Computers, 32*(3),
///   396-402. https://doi.org/10.3758/BF03200807 (Paper not read; the
///   accompanying map.m / map.sps programs were read in full.)
/// Velicer, W. F., Eaton, C. A., & Fava, J. L. (2000). Construct
///   explication through factor or component analysis: A review and
///   evaluation of alternative procedures for determining the number of
///   factors or components. In R. D. Goffin & E. Helmes (Eds.), *Problems
///   and solutions in human assessment* (pp. 41-71). Kluwer. (Not read;
///   cited as the origin of the fourth-power revision per O'Connor's code
///   comments.)
/// Revelle, W. (2025). *psych: Procedures for psychological, psychometric,
///   and personality research* (Version 2.6.5) [R package].
///   https://CRAN.R-project.org/package=psych (VSS.R `map()` read.)
pub fn velicer_map_corr(corr: &[f64], p: usize, max_m: usize) -> Result<VelicerMapResult, String> {
    validate_corr(corr, p, "velicer_map")?;
    if max_m > p - 1 {
        return Err(format!(
            "velicer_map: max_m = {max_m} exceeds canonical bound p - 1 = {}",
            p - 1
        ));
    }
    let (eigval, eigvec) = symmetric_eigen_desc(corr, p)?;
    // Loadings A = V diag(sqrt(lambda)); materially negative eigenvalues
    // mean the input is not a correlation matrix of anything. Check the
    // full spectrum (a trailing negative eigenvalue is just as disqualifying
    // as a leading one, even when max_m = 0).
    if eigval.iter().any(|&l| l < -1e-8) {
        return Err("velicer_map: correlation matrix has a materially negative eigenvalue".into());
    }
    let denom = (p * (p - 1)) as f64;
    let mut f2 = vec![f64::NAN; max_m + 1];
    let mut f4 = vec![f64::NAN; max_m + 1];
    let (mut s2, mut s4) = (0.0, 0.0);
    for i in 0..p {
        for j in 0..p {
            if i != j {
                let v = corr[i * p + j];
                s2 += v * v;
                s4 += v * v * v * v;
            }
        }
    }
    f2[0] = s2 / denom;
    f4[0] = s4 / denom;
    for m in 1..=max_m {
        // C* = R - A_m A_m'
        let mut c = corr.to_vec();
        for i in 0..p {
            for j in 0..p {
                let mut dot = 0.0;
                for k in 0..m {
                    dot += eigvec[i * p + k] * eigvec[j * p + k] * eigval[k].max(0.0);
                }
                c[i * p + j] -= dot;
            }
        }
        let diag_ok = (0..p).all(|i| {
            let d = c[i * p + i];
            d.is_finite() && d > 1e-12
        });
        if !diag_ok {
            continue; // invalid row stays NaN (e.g. identity R after 1 pc)
        }
        let d: Vec<f64> = (0..p).map(|i| 1.0 / c[i * p + i].sqrt()).collect();
        let (mut s2, mut s4) = (0.0, 0.0);
        for i in 0..p {
            for j in 0..p {
                if i != j {
                    let v = c[i * p + j] * d[i] * d[j];
                    s2 += v * v;
                    s4 += v * v * v * v;
                }
            }
        }
        f2[m] = s2 / denom;
        f4[m] = s4 / denom;
    }
    let argmin_valid = |f: &[f64]| -> usize {
        let mut best = 0usize;
        for (m, &v) in f.iter().enumerate() {
            if v.is_finite() && (!f[best].is_finite() || v < f[best]) {
                best = m;
            }
        }
        best
    };
    Ok(VelicerMapResult {
        retained_f2: argmin_valid(&f2),
        retained_f4: argmin_valid(&f4),
        f2,
        f4,
    })
}

/// [`velicer_map_corr`] from raw data (`n x p` row-major, complete and
/// finite); computes the Pearson correlation matrix first.
pub fn velicer_map_data(
    data: &[f64],
    n: usize,
    p: usize,
    max_m: usize,
) -> Result<VelicerMapResult, String> {
    let np = n
        .checked_mul(p)
        .ok_or_else(|| format!("velicer_map: dimension overflow (n = {n}, p = {p})"))?;
    if data.len() != np {
        return Err(format!(
            "velicer_map: data length {} does not match n * p = {np}",
            data.len(),
        ));
    }
    if data.iter().any(|v| !v.is_finite()) {
        return Err("velicer_map: data must be finite (complete data required)".into());
    }
    if n < 3 {
        return Err("velicer_map: need at least 3 observations".into());
    }
    let r = correlation_matrix(data, n, p)?;
    velicer_map_corr(&r, p, max_m)
}

#[cfg(test)]
#[path = "../../../tests/unit/factor_tests.rs"]
mod tests;
