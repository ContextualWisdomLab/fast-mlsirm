//! Mixed-format marginal maximum-likelihood calibration.
//!
//! Each item keeps its own conditional response function while all items share
//! the same standard-normal trait distribution. LSIRM items additionally share
//! a standard-normal latent-space coordinate; non-spatial items are constant on
//! that integration axis and therefore integrate it out exactly.
//!
//! The heterogeneous likelihood is the product of the item-specific cells, as
//! in the random-coefficients multinomial-logit framework and `mirt`'s per-item
//! `itemtype` contract. The ideal-point, GGUM, nominal, and LSIRM formulas are
//! not blended into a surrogate common formula.
//! GGUM observed-category probabilities pair the two subjective categories
//! `z` and `M-z` and use the model's symmetric threshold sequence (Roberts et
//! al., 2000).
//!
//! # References
//!
//! Adams, R. J., Wilson, M., & Wang, W.-C. (1997). The multidimensional random
//! coefficients multinomial logit model. *Applied Psychological Measurement,
//! 21*(1), 1–23. https://doi.org/10.1177/0146621697211001
//!
//! Barton, M. A., & Lord, F. M. (1981). An upper asymptote for the
//! three-parameter logistic item-response model. *ETS Research Report Series,
//! 1981*(1), i–8. https://doi.org/10.1002/j.2333-8504.1981.tb01255.x
//!
//! Bock, R. D. (1972). Estimating item parameters and latent ability when
//! responses are scored in two or more nominal categories. *Psychometrika,
//! 37*(1), 29–51. https://doi.org/10.1007/BF02291411
//!
//! Jeon, M., Jin, I. H., Schweinberger, M., & Baugh, S. (2021). Mapping
//! unobserved item-respondent interactions: A latent space item response model
//! with interaction map. *Psychometrika, 86*(2), 378–403.
//! https://doi.org/10.1007/s11336-021-09762-5
//!
//! Masters, G. N. (1982). A Rasch model for partial credit scoring.
//! *Psychometrika, 47*(2), 149–174. https://doi.org/10.1007/BF02296272
//!
//! Maydeu-Olivares, A., Hernández, A., & McDonald, R. P. (2006). A
//! multidimensional ideal point item response theory model for binary data.
//! *Multivariate Behavioral Research, 41*(4), 445–472.
//! https://doi.org/10.1207/s15327906mbr4104_2
//!
//! Roberts, J. S., Donoghue, J. R., & Laughlin, J. E. (1998). The generalized
//! graded unfolding model: A general parametric item response model for
//! unfolding graded responses. *ETS Research Report Series, 1998*(2), i–53.
//! https://doi.org/10.1002/j.2333-8504.1998.tb01781.x
//!
//! Roberts, J. S., Donoghue, J. R., & Laughlin, J. E. (2000). A general item
//! response theory model for unfolding unidimensional polytomous responses.
//! *Applied Psychological Measurement, 24*(1), 3–32.
//! https://doi.org/10.1177/01466216000241001
//!
//! Shim, H., Bonifay, W., & Wiedermann, W. (2023). Parsimonious asymmetric
//! item response theory modeling with the complementary log-log link.
//! *Behavior Research Methods, 55*(1), 200–219.
//! https://doi.org/10.3758/s13428-022-01824-5
//!
//! Tutz, G. (1990). Sequential item response models with an ordered response.
//! *British Journal of Mathematical and Statistical Psychology, 43*(1),
//! 39–55. https://doi.org/10.1111/j.2044-8317.1990.tb00925.x

use std::thread;

use crate::poly::{gpcm_logprobs, grm_logprobs, solve_small};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MixedItemKind {
    Rasch,
    TwoPl,
    ThreePl,
    ThreePlUpper,
    FourPl,
    Cll,
    Grm,
    Pcm,
    Gpcm,
    Sequential,
    Tutz,
    Nominal,
    Ideal,
    Ggum,
    Lsirm,
    LsirmGrm,
    LsirmGpcm,
}

impl MixedItemKind {
    pub fn parse(value: &str) -> Result<Self, String> {
        match value.trim().to_ascii_lowercase().as_str() {
            "rasch" | "1pl" => Ok(Self::Rasch),
            "2pl" | "dichotomous" | "binary" => Ok(Self::TwoPl),
            "3pl" => Ok(Self::ThreePl),
            "3plu" | "upper_3pl" => Ok(Self::ThreePlUpper),
            "4pl" => Ok(Self::FourPl),
            "cll" | "complementary_log_log" => Ok(Self::Cll),
            "grm" | "graded" => Ok(Self::Grm),
            "pcm" | "partial_credit" => Ok(Self::Pcm),
            "gpcm" => Ok(Self::Gpcm),
            "sequential" => Ok(Self::Sequential),
            "tutz" => Ok(Self::Tutz),
            "nominal" | "nrm" => Ok(Self::Nominal),
            "ideal" | "ideal_point" => Ok(Self::Ideal),
            "ggum" => Ok(Self::Ggum),
            "lsirm" | "lsirm_2pl" => Ok(Self::Lsirm),
            "lsirm_grm" => Ok(Self::LsirmGrm),
            "lsirm_gpcm" => Ok(Self::LsirmGpcm),
            other => Err(format!(
                "unsupported mixed item model {other:?}; expected one of: rasch, 2pl, 3pl, 3plu, 4pl, cll, grm, pcm, gpcm, sequential, tutz, nominal, ideal, ggum, lsirm, lsirm_grm, lsirm_gpcm"
            )),
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Rasch => "rasch",
            Self::TwoPl => "2pl",
            Self::ThreePl => "3pl",
            Self::ThreePlUpper => "3plu",
            Self::FourPl => "4pl",
            Self::Cll => "cll",
            Self::Grm => "grm",
            Self::Pcm => "pcm",
            Self::Gpcm => "gpcm",
            Self::Sequential => "sequential",
            Self::Tutz => "tutz",
            Self::Nominal => "nominal",
            Self::Ideal => "ideal",
            Self::Ggum => "ggum",
            Self::Lsirm => "lsirm",
            Self::LsirmGrm => "lsirm_grm",
            Self::LsirmGpcm => "lsirm_gpcm",
        }
    }

    fn is_spatial(self) -> bool {
        matches!(self, Self::Lsirm | Self::LsirmGrm | Self::LsirmGpcm)
    }

    /// Whether this family's latent-orientation reflection `(a, theta) ->
    /// (-a, -theta)` is absorbed by the SLOPE, which is what makes a slope
    /// anchor able to pin the sign. True for the slope-intercept families and
    /// for the latent-space ones, where `base = a*theta - distance(xi, zeta)`
    /// takes theta linearly and the distance lives in a space theta is not part
    /// of. FALSE for `Ideal` and `Ggum`, which absorb it through the person and
    /// item LOCATIONS with the slope untouched, and false for the fixed-slope
    /// families, which cannot absorb it at all and so pin the orientation
    /// themselves. Pinned against the cells in the module's tests.
    fn absorbs_reflection_in_slope(self) -> bool {
        self.has_free_slope() && !matches!(self, Self::Ideal | Self::Ggum)
    }

    fn has_free_slope(self) -> bool {
        matches!(
            self,
            Self::TwoPl
                | Self::ThreePl
                | Self::ThreePlUpper
                | Self::FourPl
                | Self::Grm
                | Self::Gpcm
                | Self::Sequential
                | Self::Ideal
                | Self::Ggum
                | Self::Lsirm
                | Self::LsirmGrm
                | Self::LsirmGpcm
        )
    }

    fn requires_binary(self) -> bool {
        matches!(
            self,
            Self::Rasch
                | Self::TwoPl
                | Self::ThreePl
                | Self::ThreePlUpper
                | Self::FourPl
                | Self::Cll
                | Self::Ideal
                | Self::Lsirm
        )
    }
}

#[derive(Clone, Debug)]
pub struct MixedItemSpec {
    pub kind: MixedItemKind,
    pub n_categories: usize,
}

/// Optimizer bound on every free parameter of an item, on the parameter's own
/// working scale. These are numerical guards on the M-step, not model claims:
/// an estimate resting on one is the bound, not an interior optimum, which is
/// why [`MixedItemEstimate::at_bound`] reports it to the caller.
const PARAM_BOUND: (f64, f64) = (-12.0, 12.0);
/// Optimizer bound on the slope of a family that absorbs the reflection in its
/// slope. Symmetric on the natural scale, so it bounds MAGNITUDE without
/// constraining sign: a reverse-keyed item is estimated with a negative slope
/// rather than floored.
const SLOPE_BOUND: (f64, f64) = (-SLOPE_MAGNITUDE, SLOPE_MAGNITUDE);
/// Largest slope magnitude the M-step accepts, on the natural scale. The same
/// value `crate::twopl`, `crate::mhrm`, `crate::mmle`, `crate::testlet` and
/// `crate::mixture` already use, so one item does not have a different
/// reachable range depending on which entry point fitted it. It is a numerical
/// guard chosen for consistency across the crate, not a value any source
/// states; a slope resting on it is reported through
/// [`MixedItemEstimate::at_bound`] rather than passed off as an estimate.
///
/// This tightens the previous ceiling, which was `exp(4)` only because the old
/// `log a` parametrization bounded the log scale at 4. A discrimination above
/// 10 is a degenerate fit rather than a measurement, and it is now visible
/// instead of silent.
const SLOPE_MAGNITUDE: f64 = 10.0;
/// Optimizer bound on the `log a` slope of `Ideal` and `Ggum`. Those families
/// absorb the reflection through their locations, so their slope sign carries
/// no orientation information and is held positive for identification; this
/// bounds `a` to roughly `0.0067 ..= 54.6`.
const UNFOLDING_LOG_SLOPE_BOUND: (f64, f64) = (-5.0, 4.0);
/// Optimizer bound on each latent-space coordinate of a spatial family.
const SPATIAL_BOUND: (f64, f64) = (-6.0, 6.0);

/// `at_bound` role for the slope of a free-slope family.
pub const AT_BOUND_SLOPE: &str = "slope";
/// `at_bound` role for a latent-space coordinate of a spatial family.
pub const AT_BOUND_LATENT_POSITION: &str = "latent_position";
/// `at_bound` role for any other free parameter of the item.
pub const AT_BOUND_PARAMETER: &str = "parameter";

#[derive(Clone, Debug)]
pub struct MixedItemEstimate {
    pub kind: MixedItemKind,
    pub n_categories: usize,
    pub slope: Option<f64>,
    pub intercepts: Vec<f64>,
    pub thresholds: Vec<f64>,
    pub scores: Vec<f64>,
    pub location: Option<f64>,
    pub lower_asymptote: Option<f64>,
    pub upper_asymptote: Option<f64>,
    pub zeta: Vec<f64>,
    /// Parameter roles whose estimate rests on an optimizer bound at the
    /// returned solution: [`AT_BOUND_SLOPE`], [`AT_BOUND_LATENT_POSITION`],
    /// [`AT_BOUND_PARAMETER`]. Empty is the normal case. A non-empty entry
    /// means the reported value IS the bound and the optimizer was still
    /// pushing against it, so that value is not an estimate of the parameter
    /// and must not be read as one — in particular a bounded slope is
    /// indistinguishable, in the reported number alone, from a genuinely
    /// small discrimination.
    pub at_bound: Vec<&'static str>,
}

#[derive(Clone, Debug)]
pub struct MixedFit {
    pub items: Vec<MixedItemEstimate>,
    pub theta_eap: Vec<f64>,
    pub theta_sd: Vec<f64>,
    pub xi_eap: Vec<f64>,
    pub latent_dim: usize,
    pub loglik: f64,
    pub loglik_trace: Vec<f64>,
    pub n_iter: usize,
    pub converged: bool,
    pub termination_reason: String,
    pub n_threads: usize,
}

#[derive(Clone)]
struct Grid {
    theta: Vec<f64>,
    theta_logw: Vec<f64>,
    xi: Vec<f64>,
    xi_logw: Vec<f64>,
    latent_dim: usize,
    n_xi: usize,
}

impl Grid {
    fn cell(&self) -> usize {
        self.theta.len() * self.n_xi
    }
}

fn tensor_grid(q_xi: usize, latent_dim: usize) -> Result<(Vec<f64>, Vec<f64>), String> {
    let (nodes, weights) =
        crate::quadrature::gh_rule(q_xi).ok_or_else(|| format!("unsupported q_xi {q_xi}"))?;
    let n_xi = nodes
        .len()
        .checked_pow(latent_dim as u32)
        .ok_or("q_xi ** latent_dim overflow")?;
    if n_xi > 200_000 {
        return Err("q_xi ** latent_dim exceeds the tensor-grid limit".into());
    }
    let mut grid = vec![0.0; n_xi * latent_dim];
    let mut logw = vec![0.0; n_xi];
    for idx in 0..n_xi {
        let mut rem = idx;
        for d in 0..latent_dim {
            let j = rem % nodes.len();
            rem /= nodes.len();
            grid[idx * latent_dim + d] = nodes[j];
            logw[idx] += weights[j].ln();
        }
    }
    Ok((grid, logw))
}

fn build_grid(
    specs: &[MixedItemSpec],
    latent_dim: usize,
    q_theta: usize,
    q_xi: usize,
) -> Result<Grid, String> {
    let (theta, theta_w) = crate::quadrature::gh_rule(q_theta)
        .ok_or_else(|| format!("unsupported q_theta {q_theta}"))?;
    let spatial = specs.iter().any(|s| s.kind.is_spatial());
    let (xi, xi_logw, used_dim) = if spatial {
        if !(1..=3).contains(&latent_dim) {
            return Err("latent_dim must be in 1..=3 when LSIRM items are present".into());
        }
        let (x, w) = tensor_grid(q_xi, latent_dim)?;
        (x, w, latent_dim)
    } else {
        (Vec::new(), vec![0.0], 0)
    };
    Ok(Grid {
        theta: theta.to_vec(),
        theta_logw: theta_w.iter().map(|w| w.ln()).collect(),
        xi,
        n_xi: xi_logw.len(),
        xi_logw,
        latent_dim: used_dim,
    })
}

fn ordered_values(raw: &[f64]) -> Vec<f64> {
    if raw.is_empty() {
        return Vec::new();
    }
    let mut values = Vec::with_capacity(raw.len());
    values.push(raw[0]);
    for &log_gap in &raw[1..] {
        let gap = log_gap.clamp(-8.0, 5.0).exp().max(1e-4);
        values.push(values.last().copied().unwrap() - gap);
    }
    values
}

fn ordered_raw(values: &[f64]) -> Vec<f64> {
    if values.is_empty() {
        return Vec::new();
    }
    let mut raw = Vec::with_capacity(values.len());
    raw.push(values[0]);
    for pair in values.windows(2) {
        raw.push((pair[0] - pair[1]).max(1e-4).ln());
    }
    raw
}

fn logaddexp(a: f64, b: f64) -> f64 {
    let m = a.max(b);
    m + ((a - m).exp() + (b - m).exp()).ln()
}

fn softmax_log(scores: &[f64]) -> Vec<f64> {
    let m = scores.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let z: f64 = scores.iter().map(|v| (v - m).exp()).sum();
    scores.iter().map(|v| v - m - z.ln()).collect()
}

fn logistic(value: f64) -> f64 {
    if value >= 0.0 {
        1.0 / (1.0 + (-value).exp())
    } else {
        let exp_value = value.exp();
        exp_value / (1.0 + exp_value)
    }
}

fn logit(probability: f64) -> f64 {
    let probability = probability.clamp(1e-6, 1.0 - 1e-6);
    (probability / (1.0 - probability)).ln()
}

fn binary_logprobs(probability: f64) -> Vec<f64> {
    let probability = probability.clamp(1e-15, 1.0 - 1e-15);
    vec![(-probability).ln_1p(), probability.ln()]
}

fn asymptotes(kind: MixedItemKind, params: &[f64]) -> (f64, f64) {
    match kind {
        MixedItemKind::ThreePl => (logistic(params[2]), 1.0),
        MixedItemKind::ThreePlUpper => (0.0, logistic(params[2])),
        MixedItemKind::FourPl => {
            let lower = logistic(params[2]);
            let upper = lower + (1.0 - lower) * logistic(params[3]);
            (lower, upper)
        }
        _ => (0.0, 1.0),
    }
}

fn sequential_logprobs(base: f64, transitions: &[f64]) -> Vec<f64> {
    let mut out = Vec::with_capacity(transitions.len() + 1);
    let mut reached = 0.0;
    for &intercept in transitions {
        let eta = base + intercept;
        let log_pass = -logaddexp(0.0, -eta);
        let log_stop = -logaddexp(0.0, eta);
        out.push(reached + log_stop);
        reached += log_pass;
    }
    out.push(reached);
    out
}

fn distance(xi: &[f64], zeta: &[f64]) -> f64 {
    let d2 = xi
        .iter()
        .zip(zeta)
        .map(|(x, z)| (x - z) * (x - z))
        .sum::<f64>();
    (d2 + 1e-8).sqrt()
}

fn item_logprobs(
    spec: &MixedItemSpec,
    params: &[f64],
    theta: f64,
    xi: &[f64],
    latent_dim: usize,
) -> Vec<f64> {
    let k = spec.n_categories;
    match spec.kind {
        MixedItemKind::Rasch => {
            let probability = logistic(theta - params[0]);
            binary_logprobs(probability)
        }
        MixedItemKind::TwoPl => {
            let a = params[0];
            gpcm_logprobs(a * theta, &[0.0, 1.0], &[0.0, params[1]])
        }
        MixedItemKind::ThreePl | MixedItemKind::ThreePlUpper | MixedItemKind::FourPl => {
            let a = params[0];
            let core = logistic(a * theta + params[1]);
            let (lower, upper) = asymptotes(spec.kind, params);
            binary_logprobs(lower + (upper - lower) * core)
        }
        MixedItemKind::Cll => {
            let exp_eta = (theta - params[0]).clamp(-40.0, 40.0).exp();
            binary_logprobs(-(-exp_eta).exp_m1())
        }
        MixedItemKind::Grm => {
            let a = params[0];
            grm_logprobs(a * theta, &ordered_values(&params[1..]))
        }
        MixedItemKind::Pcm => {
            let scores: Vec<f64> = (0..k).map(|c| c as f64).collect();
            let mut intercepts = vec![0.0; k];
            intercepts[1..].copy_from_slice(&params[..k - 1]);
            gpcm_logprobs(theta, &scores, &intercepts)
        }
        MixedItemKind::Gpcm => {
            let a = params[0];
            let scores: Vec<f64> = (0..k).map(|c| c as f64).collect();
            let mut intercepts = vec![0.0; k];
            intercepts[1..].copy_from_slice(&params[1..k]);
            gpcm_logprobs(a * theta, &scores, &intercepts)
        }
        MixedItemKind::Nominal => {
            let c = k - 1;
            let mut scores = vec![0.0; k];
            let mut intercepts = vec![0.0; k];
            scores[1..].copy_from_slice(&params[..c]);
            intercepts[1..].copy_from_slice(&params[c..2 * c]);
            gpcm_logprobs(theta, &scores, &intercepts)
        }
        MixedItemKind::Sequential => {
            let a = params[0];
            sequential_logprobs(a * theta, &params[1..])
        }
        MixedItemKind::Tutz => sequential_logprobs(theta, params),
        MixedItemKind::Ideal => {
            // Kept on the log scale, and kept positive, deliberately: this family
            // absorbs the reflection through its LOCATION, not its slope (see
            // `absorbs_reflection_in_slope`), so a free sign here would be
            // unidentified rather than informative.
            let a = params[0].clamp(UNFOLDING_LOG_SLOPE_BOUND.0, UNFOLDING_LOG_SLOPE_BOUND.1).exp();
            let z = a * (theta - params[1]);
            let p1 = (-0.5 * z * z).exp().clamp(1e-15, 1.0 - 1e-15);
            vec![(-p1).ln_1p(), p1.ln()]
        }
        MixedItemKind::Ggum => {
            // Kept on the log scale, and kept positive, deliberately: this family
            // absorbs the reflection through its LOCATION, not its slope (see
            // `absorbs_reflection_in_slope`), so a free sign here would be
            // unidentified rather than informative.
            let a = params[0].clamp(UNFOLDING_LOG_SLOPE_BOUND.0, UNFOLDING_LOG_SLOPE_BOUND.1).exp();
            let delta = params[1];
            let thresholds = ordered_values(&params[2..]);
            let c = k - 1;
            let m = 2 * c + 1;
            let mut tau = vec![0.0; m + 1];
            tau[1..=c].copy_from_slice(&thresholds);
            for z in 1..=c {
                tau[m - z + 1] = -thresholds[z - 1];
            }
            let mut cumulative_tau = 0.0;
            let mut log_f = Vec::with_capacity(m + 1);
            for (w, &tau_w) in tau.iter().enumerate() {
                cumulative_tau += tau_w;
                log_f.push(a * (w as f64 * (theta - delta) - cumulative_tau));
            }
            let paired: Vec<f64> = (0..=c).map(|z| logaddexp(log_f[z], log_f[m - z])).collect();
            softmax_log(&paired)
        }
        MixedItemKind::Lsirm => {
            let a = params[0];
            let cat_n = k - 1;
            let zeta = &params[1 + cat_n..1 + cat_n + latent_dim];
            let base = a * theta - distance(xi, zeta);
            gpcm_logprobs(base, &[0.0, 1.0], &[0.0, params[1]])
        }
        MixedItemKind::LsirmGrm => {
            let a = params[0];
            let zeta = &params[k..k + latent_dim];
            let base = a * theta - distance(xi, zeta);
            grm_logprobs(base, &ordered_values(&params[1..k]))
        }
        MixedItemKind::LsirmGpcm => {
            let a = params[0];
            let zeta = &params[k..k + latent_dim];
            let base = a * theta - distance(xi, zeta);
            let scores: Vec<f64> = (0..k).map(|c| c as f64).collect();
            let mut intercepts = vec![0.0; k];
            intercepts[1..].copy_from_slice(&params[1..k]);
            gpcm_logprobs(base, &scores, &intercepts)
        }
    }
}

fn parameter_count(spec: &MixedItemSpec, latent_dim: usize) -> usize {
    match spec.kind {
        MixedItemKind::Rasch | MixedItemKind::Cll => 1,
        MixedItemKind::TwoPl | MixedItemKind::Ideal => 2,
        MixedItemKind::ThreePl | MixedItemKind::ThreePlUpper => 3,
        MixedItemKind::FourPl => 4,
        MixedItemKind::Grm | MixedItemKind::Gpcm => spec.n_categories,
        MixedItemKind::Pcm | MixedItemKind::Tutz => spec.n_categories - 1,
        MixedItemKind::Sequential => spec.n_categories,
        MixedItemKind::Nominal => 2 * (spec.n_categories - 1),
        MixedItemKind::Ggum => 2 + spec.n_categories - 1,
        MixedItemKind::Lsirm | MixedItemKind::LsirmGrm | MixedItemKind::LsirmGpcm => {
            spec.n_categories + latent_dim
        }
    }
}

fn initial_params(
    spec: &MixedItemSpec,
    freq: &[f64],
    item: usize,
    n_items: usize,
    latent_dim: usize,
) -> Vec<f64> {
    let k = spec.n_categories;
    let mut p = vec![0.0; parameter_count(spec, latent_dim)];
    if spec.kind.absorbs_reflection_in_slope() {
        // a = 1 on the natural scale. `Ideal` and `Ggum` keep the log scale, so
        // their zero already means a = 1 and is left alone.
        p[0] = 1.0;
    }
    match spec.kind {
        MixedItemKind::Rasch => {
            p[0] = (freq[0] / freq[1]).ln();
        }
        MixedItemKind::TwoPl | MixedItemKind::Lsirm => {
            p[1] = (freq[1] / freq[0]).ln();
        }
        MixedItemKind::ThreePl | MixedItemKind::ThreePlUpper | MixedItemKind::FourPl => {
            let observed = freq[1].clamp(1e-4, 1.0 - 1e-4);
            let lower = if matches!(spec.kind, MixedItemKind::ThreePl | MixedItemKind::FourPl) {
                0.05
            } else {
                0.0
            };
            let upper = if matches!(
                spec.kind,
                MixedItemKind::ThreePlUpper | MixedItemKind::FourPl
            ) {
                0.95
            } else {
                1.0
            };
            p[1] = logit((observed - lower) / (upper - lower));
            if spec.kind == MixedItemKind::ThreePl {
                p[2] = logit(lower);
            } else if spec.kind == MixedItemKind::ThreePlUpper {
                p[2] = logit(upper);
            } else {
                p[2] = logit(lower);
                p[3] = logit((upper - lower) / (1.0 - lower));
            }
        }
        MixedItemKind::Cll => {
            let probability = freq[1].clamp(1e-6, 1.0 - 1e-6);
            p[0] = -(-(-probability).ln_1p()).ln();
        }
        MixedItemKind::Grm | MixedItemKind::LsirmGrm => {
            let mut thresholds = vec![0.0; k - 1];
            let mut cumulative = 0.0;
            for category in (1..k).rev() {
                cumulative += freq[category];
                let c = cumulative.clamp(1e-4, 1.0 - 1e-4);
                thresholds[category - 1] = (c / (1.0 - c)).ln();
            }
            p[1..k].copy_from_slice(&ordered_raw(&thresholds));
        }
        MixedItemKind::Pcm => {
            for category in 1..k {
                p[category - 1] = (freq[category] / freq[0]).ln();
            }
        }
        MixedItemKind::Gpcm | MixedItemKind::LsirmGpcm => {
            for category in 1..k {
                p[category] = (freq[category] / freq[0]).ln();
            }
        }
        MixedItemKind::Nominal => {
            let c = k - 1;
            for category in 1..k {
                p[category - 1] = category as f64;
                p[c + category - 1] = (freq[category] / freq[0]).ln();
            }
        }
        MixedItemKind::Sequential => {
            for transition in 1..k {
                let reached: f64 = freq[transition - 1..].iter().sum();
                let passed: f64 = freq[transition..].iter().sum();
                p[transition] = logit(passed / reached);
            }
        }
        MixedItemKind::Tutz => {
            for transition in 1..k {
                let reached: f64 = freq[transition - 1..].iter().sum();
                let passed: f64 = freq[transition..].iter().sum();
                p[transition - 1] = logit(passed / reached);
            }
        }
        MixedItemKind::Ideal => {
            p[0] = 0.0;
            p[1] = if freq[1] < 0.4 { 1.0 } else { 0.0 };
        }
        MixedItemKind::Ggum => {
            p[0] = 0.0;
            p[1] = 0.0;
            let thresholds: Vec<f64> = (0..k - 1).map(|j| 1.0 - 0.5 * j as f64).collect();
            p[2..].copy_from_slice(&ordered_raw(&thresholds));
        }
    }
    if spec.kind.is_spatial() {
        let start = p.len() - latent_dim;
        let angle = 2.0 * std::f64::consts::PI * item as f64 / n_items.max(1) as f64;
        p[start] = 0.5 * angle.cos();
        if latent_dim > 1 {
            p[start + 1] = 0.5 * angle.sin();
        }
        if latent_dim > 2 {
            p[start + 2] = 0.25 * (2.0 * angle).cos();
        }
    }
    p
}

fn item_table(spec: &MixedItemSpec, params: &[f64], grid: &Grid) -> Vec<f64> {
    let mut table = vec![0.0; grid.cell() * spec.n_categories];
    for (t, &theta) in grid.theta.iter().enumerate() {
        for x in 0..grid.n_xi {
            let xi = if grid.latent_dim == 0 {
                &[][..]
            } else {
                &grid.xi[x * grid.latent_dim..(x + 1) * grid.latent_dim]
            };
            let lp = item_logprobs(spec, params, theta, xi, grid.latent_dim);
            let node = t * grid.n_xi + x;
            table[node * spec.n_categories..(node + 1) * spec.n_categories].copy_from_slice(&lp);
        }
    }
    table
}

fn build_tables(specs: &[MixedItemSpec], params: &[Vec<f64>], grid: &Grid) -> Vec<Vec<f64>> {
    specs
        .iter()
        .zip(params)
        .map(|(spec, p)| item_table(spec, p, grid))
        .collect()
}

#[derive(Debug)]
struct EStep {
    loglik: f64,
    counts: Vec<Vec<f64>>,
}

fn empty_counts(specs: &[MixedItemSpec], cell: usize) -> Vec<Vec<f64>> {
    specs
        .iter()
        .map(|spec| vec![0.0; cell * spec.n_categories])
        .collect()
}

#[allow(clippy::too_many_arguments)]
fn e_step_range(
    y: &[usize],
    observed: &[bool],
    n_items: usize,
    specs: &[MixedItemSpec],
    tables: &[Vec<f64>],
    grid: &Grid,
    start: usize,
    end: usize,
) -> EStep {
    let cell = grid.cell();
    let mut counts = empty_counts(specs, cell);
    let mut log_node = vec![0.0; cell];
    let mut loglik = 0.0;
    for person in start..end {
        for t in 0..grid.theta.len() {
            for x in 0..grid.n_xi {
                log_node[t * grid.n_xi + x] = grid.theta_logw[t] + grid.xi_logw[x];
            }
        }
        for item in 0..n_items {
            if !observed[person * n_items + item] {
                continue;
            }
            let response = y[person * n_items + item];
            let k = specs[item].n_categories;
            for node in 0..cell {
                log_node[node] += tables[item][node * k + response];
            }
        }
        let mx = log_node.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let denom: f64 = log_node.iter().map(|v| (v - mx).exp()).sum();
        loglik += mx + denom.ln();
        for item in 0..n_items {
            if !observed[person * n_items + item] {
                continue;
            }
            let response = y[person * n_items + item];
            let k = specs[item].n_categories;
            for node in 0..cell {
                counts[item][node * k + response] += (log_node[node] - mx).exp() / denom;
            }
        }
    }
    EStep { loglik, counts }
}

#[allow(clippy::too_many_arguments)]
fn e_step(
    y: &[usize],
    observed: &[bool],
    n_persons: usize,
    n_items: usize,
    specs: &[MixedItemSpec],
    tables: &[Vec<f64>],
    grid: &Grid,
    n_threads: usize,
) -> EStep {
    let workers = n_threads.min(n_persons).max(1);
    if workers == 1 || n_persons < 256 {
        return e_step_range(y, observed, n_items, specs, tables, grid, 0, n_persons);
    }
    let chunk = n_persons.div_ceil(workers);
    let mut partials = thread::scope(|scope| {
        let mut handles = Vec::new();
        for worker in 0..workers {
            let start = worker * chunk;
            let end = (start + chunk).min(n_persons);
            handles.push(scope.spawn(move || {
                e_step_range(y, observed, n_items, specs, tables, grid, start, end)
            }));
        }
        handles
            .into_iter()
            .map(|h| h.join().expect("mixed E-step worker panicked"))
            .collect::<Vec<_>>()
    });
    let mut out = EStep {
        loglik: 0.0,
        counts: empty_counts(specs, grid.cell()),
    };
    for partial in partials.drain(..) {
        out.loglik += partial.loglik;
        for (dst_item, src_item) in out.counts.iter_mut().zip(partial.counts) {
            for (dst, src) in dst_item.iter_mut().zip(src_item) {
                *dst += src;
            }
        }
    }
    out
}

fn item_objective(spec: &MixedItemSpec, params: &[f64], grid: &Grid, counts: &[f64]) -> f64 {
    let table = item_table(spec, params, grid);
    -counts.iter().zip(table).map(|(r, lp)| r * lp).sum::<f64>()
}

fn numeric_gradient(spec: &MixedItemSpec, params: &[f64], grid: &Grid, counts: &[f64]) -> Vec<f64> {
    let mut grad = vec![0.0; params.len()];
    for j in 0..params.len() {
        let h = 1e-5 * (1.0 + params[j].abs());
        let mut plus = params.to_vec();
        let mut minus = params.to_vec();
        plus[j] += h;
        minus[j] -= h;
        grad[j] = (item_objective(spec, &plus, grid, counts)
            - item_objective(spec, &minus, grid, counts))
            / (2.0 * h);
    }
    grad
}

fn clamp_params(spec: &MixedItemSpec, values: &mut [f64], latent_dim: usize) {
    // The slope is excluded from the general bound and governed by its own.
    // On the natural scale `PARAM_BOUND` would otherwise bind first and make
    // the slope bound dead, silently tightening the reachable range below what
    // the previous `log a` parametrization allowed.
    let first_general = usize::from(spec.kind.has_free_slope());
    for value in values.iter_mut().skip(first_general) {
        *value = value.clamp(PARAM_BOUND.0, PARAM_BOUND.1);
    }
    if spec.kind.absorbs_reflection_in_slope() {
        values[0] = values[0].clamp(SLOPE_BOUND.0, SLOPE_BOUND.1);
    } else if spec.kind.has_free_slope() {
        values[0] = values[0].clamp(UNFOLDING_LOG_SLOPE_BOUND.0, UNFOLDING_LOG_SLOPE_BOUND.1);
    }
    if spec.kind.is_spatial() {
        let start = values.len() - latent_dim;
        for value in &mut values[start..] {
            *value = value.clamp(SPATIAL_BOUND.0, SPATIAL_BOUND.1);
        }
    }
}

/// Which bounds [`clamp_params`] is holding at `params`. Reads the same
/// constants the clamp applies, so the report cannot drift from the bound.
fn bounds_in_force(spec: &MixedItemSpec, params: &[f64], latent_dim: usize) -> Vec<&'static str> {
    let on = |value: f64, bound: (f64, f64)| value <= bound.0 || value >= bound.1;
    let mut roles = Vec::new();
    let slope_bound = if spec.kind.absorbs_reflection_in_slope() {
        SLOPE_BOUND
    } else {
        UNFOLDING_LOG_SLOPE_BOUND
    };
    if spec.kind.has_free_slope() && on(params[0], slope_bound) {
        roles.push(AT_BOUND_SLOPE);
    }
    let spatial_start = params.len().saturating_sub(latent_dim);
    if spec.kind.is_spatial() && params[spatial_start..].iter().any(|v| on(*v, SPATIAL_BOUND)) {
        roles.push(AT_BOUND_LATENT_POSITION);
    }
    let free_slope_offset = usize::from(spec.kind.has_free_slope());
    let others = params[free_slope_offset..spatial_start.max(free_slope_offset)].iter();
    // (the slope itself is checked above against its own bound)
    if others.copied().any(|v| on(v, PARAM_BOUND)) {
        roles.push(AT_BOUND_PARAMETER);
    }
    roles
}

fn symmetrize_and_ridge(hessian: &mut [Vec<f64>], ridge: f64) {
    let mut row = 0;
    while row < hessian.len() {
        let mut col = row + 1;
        while col < hessian.len() {
            let average = 0.5 * (hessian[row][col] + hessian[col][row]);
            hessian[row][col] = average;
            hessian[col][row] = average;
            col += 1;
        }
        hessian[row][row] += ridge;
        row += 1;
    }
}

fn m_step_item(
    spec: &MixedItemSpec,
    start: &[f64],
    grid: &Grid,
    counts: &[f64],
    max_steps: usize,
) -> Vec<f64> {
    let mut params = start.to_vec();
    for _ in 0..max_steps {
        let f0 = item_objective(spec, &params, grid, counts);
        let grad = numeric_gradient(spec, &params, grid, counts);
        let grad_norm = grad.iter().map(|g| g * g).sum::<f64>().sqrt();
        if !f0.is_finite() || !grad_norm.is_finite() || grad_norm < 1e-6 {
            break;
        }
        let n = params.len();
        let mut hessian = vec![vec![0.0; n]; n];
        for j in 0..n {
            let h = 2e-4 * (1.0 + params[j].abs());
            let mut shifted = params.clone();
            shifted[j] += h;
            let next_grad = numeric_gradient(spec, &shifted, grid, counts);
            for row in 0..n {
                hessian[row][j] = (next_grad[row] - grad[row]) / h;
            }
        }
        symmetrize_and_ridge(&mut hessian, 1e-4);
        let mut step = solve_small(hessian, grad.clone());
        if !step.iter().all(|s| s.is_finite())
            || grad.iter().zip(&step).map(|(g, s)| g * s).sum::<f64>() <= 0.0
        {
            step = grad.clone();
        }
        let max_abs = step.iter().map(|s| s.abs()).fold(0.0_f64, f64::max);
        if max_abs > 2.0 {
            for s in &mut step {
                *s *= 2.0 / max_abs;
            }
        }
        let mut alpha = 1.0;
        let directional = grad.iter().zip(&step).map(|(g, s)| g * s).sum::<f64>();
        let mut accepted = false;
        for _ in 0..24 {
            let mut candidate: Vec<f64> = params
                .iter()
                .zip(&step)
                .map(|(p, s)| p - alpha * s)
                .collect();
            clamp_params(spec, &mut candidate, grid.latent_dim);
            let fc = item_objective(spec, &candidate, grid, counts);
            if fc.is_finite() && fc <= f0 - 1e-4 * alpha * directional {
                params = candidate;
                accepted = true;
                break;
            }
            alpha *= 0.5;
        }
        if !accepted || alpha * max_abs < 1e-7 {
            break;
        }
    }
    params
}

fn m_step(
    specs: &[MixedItemSpec],
    params: &[Vec<f64>],
    grid: &Grid,
    counts: &[Vec<f64>],
    n_threads: usize,
) -> Vec<Vec<f64>> {
    let n_items = specs.len();
    let workers = n_threads.min(n_items).max(1);
    if workers == 1 || n_items < 4 {
        return (0..n_items)
            .map(|i| m_step_item(&specs[i], &params[i], grid, &counts[i], 6))
            .collect();
    }
    let chunk = n_items.div_ceil(workers);
    let mut pieces = thread::scope(|scope| {
        let mut handles = Vec::new();
        for worker in 0..workers {
            let start = worker * chunk;
            let end = (start + chunk).min(n_items);
            handles.push(scope.spawn(move || {
                let fitted = (start..end)
                    .map(|i| m_step_item(&specs[i], &params[i], grid, &counts[i], 6))
                    .collect::<Vec<_>>();
                (start, fitted)
            }));
        }
        handles
            .into_iter()
            .map(|h| h.join().expect("mixed M-step worker panicked"))
            .collect::<Vec<_>>()
    });
    pieces.sort_by_key(|(start, _)| *start);
    pieces.into_iter().flat_map(|(_, fitted)| fitted).collect()
}

fn public_estimate(spec: &MixedItemSpec, params: &[f64], latent_dim: usize) -> MixedItemEstimate {
    let k = spec.n_categories;
    let mut out = MixedItemEstimate {
        kind: spec.kind,
        n_categories: k,
        slope: None,
        intercepts: Vec::new(),
        thresholds: Vec::new(),
        scores: Vec::new(),
        location: None,
        lower_asymptote: None,
        upper_asymptote: None,
        zeta: Vec::new(),
        at_bound: bounds_in_force(spec, params, latent_dim),
    };
    match spec.kind {
        MixedItemKind::Rasch => {
            out.slope = Some(1.0);
            out.location = Some(params[0]);
        }
        MixedItemKind::TwoPl => {
            out.slope = Some(params[0]);
            out.intercepts = vec![params[1]];
        }
        MixedItemKind::ThreePl | MixedItemKind::ThreePlUpper | MixedItemKind::FourPl => {
            out.slope = Some(params[0]);
            out.intercepts = vec![params[1]];
            let (lower, upper) = asymptotes(spec.kind, params);
            out.lower_asymptote = Some(lower);
            out.upper_asymptote = Some(upper);
        }
        MixedItemKind::Cll => {
            out.slope = Some(1.0);
            out.location = Some(params[0]);
        }
        MixedItemKind::Grm => {
            out.slope = Some(params[0]);
            out.thresholds = ordered_values(&params[1..]);
        }
        MixedItemKind::Pcm => {
            out.slope = Some(1.0);
            out.intercepts = params.to_vec();
        }
        MixedItemKind::Gpcm => {
            out.slope = Some(params[0]);
            out.intercepts = params[1..k].to_vec();
        }
        MixedItemKind::Nominal => {
            let c = k - 1;
            out.scores = params[..c].to_vec();
            out.intercepts = params[c..2 * c].to_vec();
        }
        MixedItemKind::Sequential => {
            out.slope = Some(params[0]);
            out.intercepts = params[1..].to_vec();
        }
        MixedItemKind::Tutz => {
            out.slope = Some(1.0);
            out.intercepts = params.to_vec();
        }
        MixedItemKind::Ideal => {
            out.slope = Some(params[0].exp());
            out.location = Some(params[1]);
        }
        MixedItemKind::Ggum => {
            out.slope = Some(params[0].exp());
            out.location = Some(params[1]);
            out.thresholds = ordered_values(&params[2..]);
        }
        MixedItemKind::Lsirm => {
            out.slope = Some(params[0]);
            out.intercepts = vec![params[1]];
            out.zeta = params[params.len() - latent_dim..].to_vec();
        }
        MixedItemKind::LsirmGrm => {
            out.slope = Some(params[0]);
            out.thresholds = ordered_values(&params[1..k]);
            out.zeta = params[params.len() - latent_dim..].to_vec();
        }
        MixedItemKind::LsirmGpcm => {
            out.slope = Some(params[0]);
            out.intercepts = params[1..k].to_vec();
            out.zeta = params[params.len() - latent_dim..].to_vec();
        }
    }
    out
}

#[allow(clippy::too_many_arguments)]
fn final_scores(
    y: &[usize],
    observed: &[bool],
    n_persons: usize,
    n_items: usize,
    specs: &[MixedItemSpec],
    tables: &[Vec<f64>],
    grid: &Grid,
) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let cell = grid.cell();
    let mut theta_eap = vec![0.0; n_persons];
    let mut theta_sd = vec![0.0; n_persons];
    let mut xi_eap = vec![0.0; n_persons * grid.latent_dim];
    let mut log_node = vec![0.0; cell];
    for person in 0..n_persons {
        for t in 0..grid.theta.len() {
            for x in 0..grid.n_xi {
                log_node[t * grid.n_xi + x] = grid.theta_logw[t] + grid.xi_logw[x];
            }
        }
        for item in 0..n_items {
            if !observed[person * n_items + item] {
                continue;
            }
            let response = y[person * n_items + item];
            let k = specs[item].n_categories;
            for node in 0..cell {
                log_node[node] += tables[item][node * k + response];
            }
        }
        let mx = log_node.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let denom: f64 = log_node.iter().map(|v| (v - mx).exp()).sum();
        let mut m1 = 0.0;
        let mut m2 = 0.0;
        for t in 0..grid.theta.len() {
            for x in 0..grid.n_xi {
                let post = (log_node[t * grid.n_xi + x] - mx).exp() / denom;
                m1 += post * grid.theta[t];
                m2 += post * grid.theta[t] * grid.theta[t];
                for d in 0..grid.latent_dim {
                    xi_eap[person * grid.latent_dim + d] += post * grid.xi[x * grid.latent_dim + d];
                }
            }
        }
        theta_eap[person] = m1;
        theta_sd[person] = (m2 - m1 * m1).max(0.0).sqrt();
    }
    (theta_eap, theta_sd, xi_eap)
}

fn assess_loglik_update(current: f64, candidate: f64) -> Result<f64, &'static str> {
    if !candidate.is_finite() {
        return Err("non_finite_loglik");
    }
    let change = candidate - current;
    let monotone_slack = 1e-8 * (1.0 + current.abs());
    if change < -monotone_slack {
        return Err("non_monotone_update");
    }
    Ok(change)
}

fn contextualize_mixed_update(update: Result<f64, &'static str>) -> Result<f64, String> {
    match update {
        Ok(change) => Ok(change),
        Err(reason) => Err(format!("mixed-format EM update failed: {reason}")),
    }
}

#[allow(clippy::too_many_arguments)]
pub fn fit_mixed_items(
    y: &[usize],
    observed: Option<&[bool]>,
    n_persons: usize,
    n_items: usize,
    specs: &[MixedItemSpec],
    latent_dim: usize,
    q_theta: usize,
    q_xi: usize,
    max_iter: usize,
    tol: f64,
    requested_threads: usize,
) -> Result<MixedFit, String> {
    if n_persons == 0 || n_items == 0 {
        return Err("responses must contain at least one person and one item".into());
    }
    let expected_len = n_persons
        .checked_mul(n_items)
        .ok_or("n_persons * n_items overflow")?;
    if y.len() != expected_len {
        return Err("y must have length n_persons * n_items".into());
    }
    if specs.len() != n_items {
        return Err("item specification count must match n_items".into());
    }
    if let Some(mask) = observed {
        if mask.len() != y.len() {
            return Err("observed must have length n_persons * n_items".into());
        }
    }
    if max_iter == 0 || !tol.is_finite() || tol <= 0.0 {
        return Err("max_iter must be positive and tol must be finite and > 0".into());
    }
    for (item, spec) in specs.iter().enumerate() {
        if spec.n_categories < 2 {
            return Err(format!("item {item}: n_categories must be >= 2"));
        }
        if spec.kind.requires_binary() && spec.n_categories != 2 {
            return Err(format!(
                "item {item}: {} requires exactly 2 categories",
                spec.kind.as_str()
            ));
        }
        let mut seen = vec![false; spec.n_categories];
        for person in 0..n_persons {
            let index = person * n_items + item;
            if observed.is_none_or(|m| m[index]) {
                let response = y[index];
                if response >= spec.n_categories {
                    return Err(format!(
                        "item {item}: observed response {response} is outside 0..{}",
                        spec.n_categories - 1
                    ));
                }
                seen[response] = true;
            }
        }
        if seen.iter().filter(|&&present| present).count() < 2 {
            return Err(format!(
                "item {item}: at least two observed categories are required"
            ));
        }
    }
    let observed_owned;
    let observed = if let Some(mask) = observed {
        mask
    } else {
        observed_owned = vec![true; y.len()];
        &observed_owned
    };
    let grid = build_grid(specs, latent_dim, q_theta, q_xi)?;
    let auto_threads = thread::available_parallelism().map_or(1, |n| n.get());
    let n_threads = if requested_threads == 0 {
        auto_threads
    } else {
        requested_threads.min(auto_threads)
    }
    .clamp(1, n_persons.max(1));

    let mut params = Vec::with_capacity(n_items);
    for (item, spec) in specs.iter().enumerate() {
        let mut freq = vec![1e-3; spec.n_categories];
        for person in 0..n_persons {
            let index = person * n_items + item;
            if observed[index] {
                freq[y[index]] += 1.0;
            }
        }
        let total: f64 = freq.iter().sum();
        for value in &mut freq {
            *value /= total;
        }
        params.push(initial_params(spec, &freq, item, n_items, grid.latent_dim));
    }

    let mut tables = build_tables(specs, &params, &grid);
    let mut state = e_step(
        y, observed, n_persons, n_items, specs, &tables, &grid, n_threads,
    );
    assess_loglik_update(state.loglik, state.loglik)
        .map_err(|_| "initial mixed-format log-likelihood is not finite")?;
    let mut trace = vec![state.loglik];
    let mut converged = false;
    let mut termination_reason = "max_iter_reached".to_string();
    let mut completed = 0;
    for iteration in 1..=max_iter {
        let candidate = m_step(specs, &params, &grid, &state.counts, n_threads);
        let candidate_tables = build_tables(specs, &candidate, &grid);
        let candidate_state = e_step(
            y,
            observed,
            n_persons,
            n_items,
            specs,
            &candidate_tables,
            &grid,
            n_threads,
        );
        let change =
            contextualize_mixed_update(assess_loglik_update(state.loglik, candidate_state.loglik))?;
        params = candidate;
        tables = candidate_tables;
        state = candidate_state;
        trace.push(state.loglik);
        completed = iteration;
        if change.abs() <= tol * (1.0 + state.loglik.abs()) {
            converged = true;
            termination_reason = "converged".to_string();
            break;
        }
    }

    let (theta_eap, theta_sd, xi_eap) =
        final_scores(y, observed, n_persons, n_items, specs, &tables, &grid);
    let mut items: Vec<MixedItemEstimate> = specs
        .iter()
        .zip(&params)
        .map(|(spec, p)| public_estimate(spec, p, grid.latent_dim))
        .collect();
    let mut theta_eap = theta_eap;
    canonicalize_bank_reflection(&mut items, &mut theta_eap);
    Ok(MixedFit {
        items,
        theta_eap,
        theta_sd,
        xi_eap,
        latent_dim: grid.latent_dim,
        loglik: state.loglik,
        loglik_trace: trace,
        n_iter: completed,
        converged,
        termination_reason,
        n_threads,
    })
}

/// Pin the bank's latent orientation, when the bank has one to pin.
///
/// `(a, theta) -> (-a, -theta)` holds the likelihood fixed only if EVERY item's
/// contribution is invariant, so whether the orientation needs a rule — and
/// whether a slope anchor can supply one — depends on which families the bank
/// contains. The three cases are pinned against the cells in this module's
/// tests:
///
///   * A family that absorbs the reflection in its slope
///     ([`MixedItemKind::absorbs_reflection_in_slope`]) can be canonicalized by
///     a slope anchor.
///   * A fixed-slope family (`Rasch`, `Cll`, `Tutz`, `Pcm`, `Nominal`) carries
///     an implicit slope of `+1` that cannot be negated, so the reflection is
///     not a symmetry of the likelihood at all and the DATA identify the
///     orientation. Imposing an anchor on top would move the answer away from
///     the maximum-likelihood solution, so this returns without touching
///     anything.
///   * `Ideal` and `Ggum` absorb the reflection through their locations with
///     the slope untouched, so they neither pin the orientation nor can be
///     canonicalized by a slope rule. A bank of only these is left unpinned
///     rather than pinned incorrectly; that gap is recorded against the module
///     rather than papered over with a rule that constrains nothing.
///
/// `location` is on theta's scale and flips with it; intercepts, thresholds,
/// scores, asymptotes and latent coordinates are invariant.
fn canonicalize_bank_reflection(items: &mut [MixedItemEstimate], theta: &mut [f64]) {
    if items.iter().any(|item| !item.kind.has_free_slope()) {
        // A fixed-slope item is present: the data pin the orientation.
        return;
    }
    let anchor = items
        .iter()
        .enumerate()
        .filter(|(_, item)| item.kind.absorbs_reflection_in_slope())
        .filter_map(|(index, item)| item.slope.map(|slope| (index, slope)))
        .max_by(|(_, left), (_, right)| left.abs().total_cmp(&right.abs()));
    let Some((_, anchor_slope)) = anchor else {
        // Every item is `Ideal` or `Ggum`: no slope carries the orientation.
        return;
    };
    if anchor_slope >= 0.0 {
        return;
    }
    for item in items.iter_mut() {
        if item.kind.absorbs_reflection_in_slope() {
            if let Some(slope) = item.slope.as_mut() {
                *slope = -*slope;
            }
        }
        if let Some(location) = item.location.as_mut() {
            *location = -*location;
        }
    }
    for value in theta.iter_mut() {
        *value = -*value;
    }
}

#[cfg(test)]
#[path = "../../../tests/unit/mixed_tests.rs"]
mod tests;
